# -*- coding: utf-8 -*-
"""
注册成功后的 Codex OAuth 授权模块（2026-06-15 改造：全新 session + 接码）。

旧方案"复用注册的已登录 session"会撞 /choose-an-account 卡死（React SPA 解析不出
可提交字段）。新方案改为用**全新干净 session**从头登录，走 OpenAI 标准风控路径，
手机号验证靠接码平台自动收码，当前通过 core.sms_provider 支持 GrizzlySMS 和 L_API.md
定义的本地 L 取号服务。

完整接口链由 Auth 返回的 page/type/continue_url 动态决定：
    - 提交邮箱后可能进入密码、邮箱 OTP 或其他验证页
    - 密码后可能进入 MFA/TOTP、邮箱 OTP、手机号验证或直接授权
    - 邮箱 OTP/MFA 后同样只在服务端明确要求时执行手机号验证
    - 最后选 workspace / 跟随重定向到 localhost:1455/auth/callback

拿到 code 后换 token / 保存到 SQLite 的逻辑（exchange_codex_token /
build_codex_storage / save_codex_credential）沿用原流程。
"""
import base64
import hashlib
import json
import logging
import random
import re
import secrets
import time
import uuid
from datetime import datetime, timezone
from urllib.parse import urlencode, urlparse, parse_qs, quote

import pyotp

# 用模块属性方式访问 config，支持 WebUI 热加载（config.reload_all()）。
# 协议级常量（CLIENT_ID/URL/SCOPE/OUTPUT_DIRNAME）虽然不会改，统一从 _cfg 读，
# 这样 reload 后立即生效，不用再分两套导入。
from config import codex as _cfg
from core.session import BrowserSession
from core.humanize import delay as human_delay
from core.openai_auth import (
    _is_transient_network_error,
    _is_retryable_authorize_error,
    _reset_retryable_circuit,
    _extract_error_code,
    detect_account_unusable_response_body,
    AccountUnusableError,
    request_sentinel_token,
    build_sentinel_header,
)
from core import db
from core import sms_provider
from curl_cffi import requests as curl_requests

logger = logging.getLogger(__name__)

# 跟重定向链时的最大跳数，防死循环
_MAX_REDIRECTS = 15

# 网络层临时性错误（代理抖动 / TLS 握手失败 / 重置）重试参数，对齐 openai_auth.follow_authorize
_NET_MAX_ATTEMPTS = 3
_NET_BACKOFF_BASE = 2.0

# Auth 响应设置 cookie 与后续 workspace/select 之间偶尔存在短暂竞态。
_WORKSPACE_COOKIE_WAIT_SECONDS = 4.0
_WORKSPACE_POLL_INTERVAL_SECONDS = 0.2


def _with_net_retry(label: str, fn):
    """
    对临时性网络错误（TLS/代理/超时/重置）做重试包装。
    非临时错误（业务 4xx 等）直接抛。最多 _NET_MAX_ATTEMPTS 次。
    """
    last_exc = None
    for attempt in range(1, _NET_MAX_ATTEMPTS + 1):
        try:
            return fn()
        except Exception as exc:
            last_exc = exc
            if not _is_transient_network_error(exc):
                raise
            if attempt >= _NET_MAX_ATTEMPTS:
                break
            backoff = _NET_BACKOFF_BASE ** (attempt - 1)
            logger.warning(
                f"[Codex] {label} 临时性网络错误 ({type(exc).__name__}: {_safe_sensitive_text(exc, limit=120)})，"
                f"{backoff:.1f}s 后重试 (尝试 {attempt}/{_NET_MAX_ATTEMPTS})..."
            )
            time.sleep(backoff)
    raise last_exc if last_exc else RuntimeError(f"[Codex] {label} 重试耗尽但无异常记录")


def _with_auth_navigation_retry(session: BrowserSession, label: str, fn):
    """对 Auth document 的 403/429/5xx 重试，并保留当前 Cookie/设备上下文。"""
    last_exc = None
    for attempt in range(1, _NET_MAX_ATTEMPTS + 1):
        try:
            resp = fn()
            status = int(getattr(resp, "status_code", 0) or 0)
            if status >= 400:
                error = RuntimeError(
                    f"{label} status={status}, body={_safe_sensitive_text(getattr(resp, 'text', ''), limit=180)}"
                )
                error.response = resp
                raise error
            return resp
        except Exception as exc:
            last_exc = exc
            if not _is_retryable_authorize_error(exc) or attempt >= _NET_MAX_ATTEMPTS:
                raise
            # Cloudflare 的 403 经常同时更新 __cf_bm。只清理本地熔断，绝不能
            # 新建 Session，否则刚得到的 Cookie 和统一 device/session ID 会丢失。
            _reset_retryable_circuit(session)
            backoff = _NET_BACKOFF_BASE ** (attempt - 1)
            logger.warning(
                "[Codex] %s 临时失败（%s/%s）：%s: %s；"
                "保留当前 session/deviceId/CF Cookie，%.1fs 后重试",
                label, attempt, _NET_MAX_ATTEMPTS, type(exc).__name__,
                _safe_sensitive_text(exc, limit=160), backoff,
            )
            time.sleep(backoff)
    raise last_exc if last_exc else RuntimeError(f"[Codex] {label} 重试耗尽")


def _codex_auth_preflight(session: BrowserSession) -> None:
    """仅预热 Codex 真正依赖的 Auth 域名，不再用 ChatGPT 首页作为硬门槛。"""
    headers = session.get_auth_navigate_headers(
        referer="", user_initiated=False, target_origin="https://auth.openai.com",
    )
    logger.info("[Codex][预检] Auth document（统一 session/deviceId）")
    _with_auth_navigation_retry(
        session,
        "auth document 预检",
        lambda: session.get(
            "https://auth.openai.com/log-in",
            headers=headers,
            allow_redirects=True,
        ),
    )


def _codex_result(
    *,
    status: str,
    ok: bool = False,
    http_status: int | None = None,
    email: str | None = None,
    file_path: str | None = None,
    callback_url: str | None = None,
    message: str = "",
) -> dict:
    """构造与 flow_trigger._flow_result 同形态的结构化结果。"""
    return {
        "status": status,
        "ok": ok,
        "http_status": http_status,
        "email": email,
        "file_path": file_path,
        "callback_url": None,
        "message": _safe_sensitive_text(message, limit=500),
    }


def _account_registration_password(email: str) -> str:
    """读取账号的注册密码；不存在则返回空字符串。"""
    try:
        acc = db.get_account_by_email(email)
        if not acc:
            return ""
        extra_raw = acc.get("extra_json")
        extra = {}
        if isinstance(extra_raw, str) and extra_raw.strip():
            try:
                extra = json.loads(extra_raw)
            except Exception:
                extra = {}
        elif isinstance(extra_raw, dict):
            extra = extra_raw
        return str(extra.get("registration_password") or acc.get("registration_password") or "").strip()
    except Exception:
        return ""


def _account_totp_secret(email: str) -> str:
    """读取账号已开启的 2FA 密钥；不存在则返回空字符串。"""
    try:
        acc = db.get_account_by_email(email)
        if not acc:
            return ""
        return str(acc.get("totp_secret") or "").strip()
    except Exception:
        return ""


def _account_totp_code(email: str) -> str:
    secret = _account_totp_secret(email)
    return pyotp.TOTP(secret).now() if secret else ""


# ============================================================
# PKCE / state（对照 CLIProxyAPI pkce.go）
# ============================================================

def _generate_pkce() -> tuple[str, str]:
    """生成 PKCE 代码对：verifier=base64url(96字节)，challenge=base64url(sha256(verifier))。"""
    verifier_bytes = secrets.token_bytes(96)
    code_verifier = base64.urlsafe_b64encode(verifier_bytes).rstrip(b"=").decode("ascii")
    digest = hashlib.sha256(code_verifier.encode("ascii")).digest()
    code_challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
    return code_verifier, code_challenge


def _generate_state() -> str:
    """生成 OAuth state 随机串，防 CSRF。"""
    return secrets.token_urlsafe(32)


def _build_authorize_url(state: str, code_challenge: str, prompt: str = "login") -> str:
    """按 CLIProxyAPI openai_auth.go 的参数集拼 Codex 授权 URL。"""
    params = {
        "client_id": _cfg.CODEX_CLIENT_ID,
        "response_type": "code",
        "redirect_uri": _cfg.CODEX_REDIRECT_URI,
        "scope": _cfg.CODEX_SCOPE,
        "state": state,
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
        "prompt": prompt,
        "id_token_add_organizations": "true",
        "codex_cli_simplified_flow": "true",
    }
    return f"{_cfg.CODEX_AUTH_URL}?{urlencode(params)}"


def _ensure_oai_context_url(auth_url: str, session: BrowserSession) -> str:
    """在 Codex OAuth 授权 URL 上补齐前端同源上下文参数，保持 oai-did 连续。"""
    try:
        parsed = urlparse(auth_url)
        params = parse_qs(parsed.query, keep_blank_values=True)
        changed = False
        additions = {
            "ext-oai-did": session.device_id,
            "auth_session_logging_id": session.auth_session_logging_id,
            "screen_hint": "login_or_signup",
        }
        for key, value in additions.items():
            if not params.get(key):
                params[key] = [value]
                changed = True
        if not changed:
            return auth_url
        query = urlencode(params, doseq=True)
        return parsed._replace(query=query).geturl()
    except Exception:
        return auth_url


# ============================================================
# CPA 管理接口：授权地址由 CPA 生成，成功回调提交给 CPA
# ============================================================

def _codex_auth_url_source() -> str:
    return str(getattr(_cfg, "CODEX_AUTH_URL_SOURCE", "cpa") or "cpa").strip().lower()


def _cpa_management_origin() -> str:
    raw = str(getattr(_cfg, "CPA_MANAGEMENT_URL", "") or "").strip()
    if not raw:
        raise RuntimeError("[Codex][CPA] 尚未配置 CPA_MANAGEMENT_URL")
    try:
        parsed = urlparse(raw)
    except Exception as exc:
        raise RuntimeError(f"[Codex][CPA] CPA_MANAGEMENT_URL 格式无效: {raw}") from exc
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise RuntimeError(f"[Codex][CPA] CPA_MANAGEMENT_URL 格式无效: {raw}")
    return f"{parsed.scheme}://{parsed.netloc}"


def _cpa_management_key() -> str:
    key = str(getattr(_cfg, "CPA_MANAGEMENT_KEY", "") or "").strip()
    if not key:
        raise RuntimeError("[Codex][CPA] 尚未配置 CPA_MANAGEMENT_KEY")
    return key


def _cpa_request_json(
    method: str,
    path: str,
    body: dict | None = None,
    *,
    timeout: int | None = None,
) -> dict:
    """调用 CPA 管理接口并返回 JSON 对象。"""
    origin = _cpa_management_origin()
    key = _cpa_management_key()
    timeout = int(timeout or getattr(_cfg, "CPA_REQUEST_TIMEOUT", 30) or 30)
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": f"Bearer {key}",
        "X-Management-Key": key,
    }
    url = f"{origin}{path}"
    session = curl_requests.Session()
    try:
        resp = session.request(
            method.upper(),
            url,
            headers=headers,
            data=None if body is None else json.dumps(body),
            timeout=timeout,
        )
        try:
            payload = resp.json()
        except Exception:
            payload = {}
        if resp.status_code < 200 or resp.status_code >= 300:
            msg = ""
            if isinstance(payload, dict):
                msg = payload.get("error") or payload.get("message") or payload.get("detail") or payload.get("reason") or ""
            raise RuntimeError(
                f"[Codex][CPA] 管理接口失败 {method.upper()} {path} status={resp.status_code}: "
                f"{msg or (resp.text or '')[:300]}"
            )
        return payload if isinstance(payload, dict) else {}
    finally:
        try:
            session.close()
        except Exception:
            pass


def _sub2_codex_base() -> str:
    from config import sub2api as _sub2_cfg
    raw = str(
        getattr(_sub2_cfg, "SUB2API_API_BASE", "")
        or getattr(_sub2_cfg, "SUB2_CODEX_API_BASE", "")
        or ""
    ).strip().rstrip("/")
    if not raw:
        raise RuntimeError("[Codex][sub2] 尚未配置 SUB2API_API_BASE")
    parsed = urlparse(raw)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise RuntimeError(f"[Codex][sub2] SUB2API_API_BASE 格式无效: {raw}")
    return raw


def _sub2_codex_headers() -> dict:
    from config import sub2api as _sub2_cfg
    token = str(getattr(_sub2_cfg, "SUB2_CODEX_API_TOKEN", "") or getattr(_sub2_cfg, "SUB2API_API_KEY", "") or getattr(_sub2_cfg, "SUB2API_API_TOKEN", "") or "").strip()
    auth_header = str(getattr(_sub2_cfg, "SUB2_CODEX_AUTH_HEADER", "") or getattr(_sub2_cfg, "SUB2API_API_AUTH_HEADER", "x-api-key") or "x-api-key").strip()
    auth_prefix = str(getattr(_sub2_cfg, "SUB2_CODEX_AUTH_PREFIX", "") or getattr(_sub2_cfg, "SUB2API_API_AUTH_PREFIX", "") or "").strip()
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "User-Agent": "turb-gpt-free-register/codex-sub2",
    }
    if token:
        headers[auth_header] = f"{auth_prefix} {token}".strip() if auth_prefix else token
    return headers


def _safe_sensitive_text(value: object, *, limit: int = 180) -> str:
    text = " ".join(str(value or "").replace("\r", " ").replace("\n", " ").split())
    text = re.sub(
        r"(?i)([\"']?\b(?:access[_ -]?token|refresh[_ -]?token|id[_ -]?token|authorization|bearer|"
        r"api[_ -]?key|password|secret|callback(?:_url)?|redirect_uri|oauth[_ -]?code|code)\b[\"']?)"
        r"\s*[:=]\s*[\"']?[^\s,;}\]\"']+",
        r"\1=[redacted]",
        text,
    )
    text = re.sub(r"(?i)\bbearer\s+[A-Za-z0-9._~+/=-]+", "bearer [redacted]", text)
    text = re.sub(r"https?://[^\s,;}\]\\\"'，。；！？、）】》]+", "[url-redacted]", text, flags=re.I)
    return text[:limit]


def _safe_url_for_log(value: object) -> str:
    try:
        parsed = urlparse(str(value or ""))
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            return "[url-redacted]"
        host = parsed.hostname
        if parsed.port:
            host = f"{host}:{parsed.port}"
        return f"{parsed.scheme}://{host}{parsed.path or '/'}"
    except (TypeError, ValueError):
        return "[url-redacted]"


def _safe_sub2_error_detail(value: object) -> str:
    return _safe_sensitive_text(value)


def _sub2_codex_request_json(method: str, path: str, body: dict | None = None) -> dict:
    from config import sub2api as _sub2_cfg
    base = _sub2_codex_base()
    timeout = int(getattr(_sub2_cfg, "SUB2API_API_TIMEOUT", 20) or 20)
    normalized_path = "/" + str(path or "").lstrip("/")
    url = f"{base}{normalized_path}"
    session = curl_requests.Session()
    try:
        resp = session.request(
            method.upper(),
            url,
            headers=_sub2_codex_headers(),
            data=None if body is None else json.dumps(body),
            timeout=timeout,
        )
        try:
            payload = resp.json()
        except Exception:
            payload = {}
        if resp.status_code < 200 or resp.status_code >= 300:
            msg = ""
            if isinstance(payload, dict):
                msg = payload.get("error") or payload.get("message") or payload.get("detail") or payload.get("reason") or ""
            detail = _safe_sub2_error_detail(msg or (resp.text or ""))
            suffix = f": {detail}" if detail else ""
            raise RuntimeError(
                f"[Codex][sub2] 接口失败 {method.upper()} {normalized_path} status={resp.status_code}{suffix}"
            )
        return payload if isinstance(payload, dict) else {}
    finally:
        try:
            session.close()
        except Exception:
            pass


def sub2api_admin_request_json(method: str, path: str, body: dict | None = None) -> dict:
    """Reuse the configured Sub2API management transport without exposing credentials."""
    return _sub2_codex_request_json(method, path, body)


def _request_sub2_authorize_url() -> dict:
    """从 sub2 生成 Codex OAuth 授权地址；本地不生成 PKCE。"""
    from config import sub2api as _sub2_cfg
    path = str(getattr(_sub2_cfg, "SUB2_CODEX_AUTH_URL_PATH", "/api/v1/admin/openai/generate-auth-url") or "/api/v1/admin/openai/generate-auth-url")
    logger.info("[Codex][sub2] 正在通过 sub2 接口生成授权地址...")
    payload = _sub2_codex_request_json("POST", path, {})
    data = payload.get("data") if isinstance(payload.get("data"), dict) else {}
    auth_url = _first_non_empty(
        payload.get("url"), payload.get("auth_url"), payload.get("authUrl"),
        data.get("url"), data.get("auth_url"), data.get("authUrl"),
    )
    session_id = _first_non_empty(
        payload.get("session_id"), payload.get("sessionId"),
        data.get("session_id"), data.get("sessionId"),
    )
    state = _first_non_empty(
        payload.get("state"), payload.get("auth_state"), payload.get("authState"),
        data.get("state"), data.get("auth_state"), data.get("authState"),
        _extract_state_from_auth_url(auth_url),
    )
    if not auth_url.startswith("http"):
        raise RuntimeError("[Codex][sub2] sub2 未返回有效 auth_url")
    if not state:
        raise RuntimeError("[Codex][sub2] 授权地址缺少 state")
    logger.info("[Codex][sub2] 已获取授权地址（授权 URL 与 state 不写日志）")
    if not session_id:
        logger.warning("[Codex][sub2] 授权地址响应缺少 session_id，后续 exchange-code 可能失败")
    return {"auth_url": auth_url, "state": state, "session_id": session_id, "origin": _sub2_codex_base(), "raw": payload}


def _summarize_sub2_response(payload: dict) -> str:
    """只记录非敏感账号标识；不回显 OAuth code、callback 或完整响应。"""
    try:
        data = payload.get("data") if isinstance(payload.get("data"), dict) else payload
        parts = []
        if isinstance(data, dict):
            for key in ("id", "account_id", "name", "email", "platform", "type"):
                value = data.get(key)
                if value not in (None, ""):
                    parts.append(f"{key}={_safe_sub2_error_detail(value)}")
        if parts:
            return " ".join(parts)
        if isinstance(payload, dict) and "success" in payload:
            return f"success={bool(payload.get('success'))}"
    except Exception:
        pass
    return "响应已接收（敏感字段不写日志）"


def _submit_sub2_callback(callback_url: str, *, session_id: str = "", redirect_uri: str = "") -> dict:
    """提交 OAuth callback 给 sub2。"""
    from config import sub2api as _sub2_cfg
    path = str(getattr(_sub2_cfg, "SUB2_CODEX_CALLBACK_PATH", "/api/v1/admin/openai/create-from-oauth") or "/api/v1/admin/openai/create-from-oauth")
    mode = str(getattr(_sub2_cfg, "SUB2_CODEX_CALLBACK_PAYLOAD_MODE", "create_from_oauth") or "create_from_oauth").strip().lower()
    if mode == "callback_url":
        body = {"callback_url": str(callback_url or "").strip()}
    elif mode == "redirect_url":
        body = {"redirect_url": str(callback_url or "").strip()}
    else:
        parsed = urlparse(str(callback_url or ""))
        qs = parse_qs(parsed.query)
        code = (qs.get("code") or [""])[0]
        state = (qs.get("state") or [""])[0]
        if not session_id:
            raise RuntimeError("[Codex][sub2] exchange-code 缺少 session_id")
        if not code:
            raise RuntimeError("[Codex][sub2] callback_url 缺少 code")
        if not state:
            raise RuntimeError("[Codex][sub2] callback_url 缺少 state")
        body = {"session_id": session_id, "code": code, "state": state}
        if redirect_uri:
            body["redirect_uri"] = redirect_uri
        if mode in {"create_from_oauth", "create-from-oauth", "create_oauth_account"}:
            body.setdefault("concurrency", 3)
            body.setdefault("priority", 50)

    max_attempts = max(1, int(getattr(_cfg, "CPA_CALLBACK_SUBMIT_RETRIES", 5) or 5))
    base_delay = max(1.0, float(getattr(_cfg, "CPA_CALLBACK_SUBMIT_RETRY_DELAY", 6) or 6))
    last_exc = None
    for attempt in range(1, max_attempts + 1):
        try:
            logger.info("[Codex][sub2] 正在上传 OAuth callback（第 %s/%s 次，callback 内容不写日志）", attempt, max_attempts)
            payload = _sub2_codex_request_json("POST", path, body)
            logger.info("[Codex][sub2] callback 已上传并处理完成（第 %s 次成功）响应=%s", attempt, _summarize_sub2_response(payload))
            return payload
        except Exception as exc:
            last_exc = exc
            retryable = _is_cpa_callback_retryable(exc)
            if attempt >= max_attempts or not retryable:
                logger.warning("[Codex][sub2] callback 上传失败且不再重试：attempt=%s/%s retryable=%s error=%s", attempt, max_attempts, retryable, _safe_sensitive_text(exc))
                raise
            delay = base_delay * attempt
            logger.warning("[Codex][sub2] callback 上传失败，将在 %.1fs 后重试：attempt=%s/%s error=%s", delay, attempt, max_attempts, _safe_sensitive_text(exc))
            time.sleep(delay)
    raise RuntimeError(f"[Codex][sub2] callback 上传失败：{last_exc}")



def _cpa_request_raw(method: str, path: str, body: dict | None = None, *, response_type: str = "text"):
    """调用 CPA 管理接口并返回原始响应；用于下载 auth-files 这类非 JSON 响应。"""
    origin = _cpa_management_origin()
    key = _cpa_management_key()
    timeout = int(getattr(_cfg, "CPA_REQUEST_TIMEOUT", 30) or 30)
    headers = {
        "Accept": "application/json, text/plain, */*",
        "Content-Type": "application/json",
        "Authorization": f"Bearer {key}",
        "X-Management-Key": key,
    }
    url = f"{origin}{path}"
    session = curl_requests.Session()
    try:
        resp = session.request(
            method.upper(),
            url,
            headers=headers,
            data=None if body is None else json.dumps(body),
            timeout=timeout,
        )
        if resp.status_code < 200 or resp.status_code >= 300:
            msg = ""
            try:
                payload = resp.json()
                if isinstance(payload, dict):
                    msg = payload.get("error") or payload.get("message") or payload.get("detail") or payload.get("reason") or ""
            except Exception:
                pass
            raise RuntimeError(
                f"[Codex][CPA] 管理接口失败 {method.upper()} {path} status={resp.status_code}: "
                f"{msg or (resp.text or '')[:300]}"
            )
        if response_type == "bytes":
            return resp.content
        return resp.text
    finally:
        try:
            session.close()
        except Exception:
            pass


def _filter_cpa_codex_files(payload: dict) -> list[dict]:
    files = payload.get("files") if isinstance(payload.get("files"), list) else None
    if files is None:
        files = payload.get("credentials") if isinstance(payload.get("credentials"), list) else None
    if files is None:
        files = payload.get("data") if isinstance(payload.get("data"), list) else []
    out = []
    for item in files:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or "").strip()
        ftype = str(item.get("type") or item.get("provider") or "").strip().lower()
        email = str(item.get("email") or "").strip().lower()
        if ftype == "codex" or name.lower().startswith("codex-") or "codex" in name.lower():
            copied = dict(item)
            copied["name"] = name
            copied["email"] = email or str(item.get("email") or "")
            out.append(copied)
    return out


def list_cpa_codex_auth_files() -> list[dict]:
    """读取兼容 v0 的 CPA auth-files 列表。"""
    return _filter_cpa_codex_files(_cpa_request_json("GET", "/v0/management/auth-files"))


def refresh_all_cpa_credentials() -> dict:
    """刷新 CPA 中的 Codex 凭证状态；无文档化刷新接口时由 CPA 返回明确错误。"""
    timeout = max(30, int(getattr(_cfg, "CPA_REQUEST_TIMEOUT", 30) or 30), 300)
    return _cpa_request_json(
        "POST",
        "/v8/management/credentials/refresh",
        {"all": True},
        timeout=timeout,
    )


def find_cpa_codex_auth_file(*, email: str = "", local_filename: str = "") -> dict | None:
    """按本地回执/凭证文件名或邮箱匹配 CPA 侧 codex auth 文件。"""
    email_l = str(email or "").strip().lower()
    local_name_l = str(local_filename or "").strip().lower()
    local_stem_l = local_name_l[:-5] if local_name_l.endswith(".json") else local_name_l
    files = list_cpa_codex_auth_files()
    if not files:
        return None

    def score(item: dict) -> int:
        name_l = str(item.get("name") or "").lower()
        item_email_l = str(item.get("email") or "").lower()
        s = 0
        if local_name_l and name_l == local_name_l:
            s = max(s, 100)
        if local_stem_l and name_l.startswith(local_stem_l):
            s = max(s, 80)
        if email_l and item_email_l == email_l:
            s = max(s, 70)
        if email_l and email_l in name_l:
            s = max(s, 60)
        # 本地 CPA 回执名一般是 codex-邮箱-cpa-callback.json，CPA 实际文件是 codex-邮箱-free.json。
        if local_stem_l.endswith("-cpa-callback"):
            base = local_stem_l[:-len("-cpa-callback")]
            if base and name_l.startswith(base + "-"):
                s = max(s, 75)
        return s

    ranked = sorted(((score(item), item) for item in files), key=lambda x: x[0], reverse=True)
    return ranked[0][1] if ranked and ranked[0][0] > 0 else None


def download_cpa_codex_auth_text(*, cpa_name: str | None = None, email: str = "", local_filename: str = "") -> tuple[str, str, dict]:
    """
    从 CPA auth-files 下载一个 Codex JSON 文本。
    Returns: (content_text, download_filename, matched_file_meta)
    """
    meta = None
    name = str(cpa_name or "").strip()
    if name:
        # 已经拿到 CPA 文件名时直接下载，不再额外拉取一次 auth-files 列表。
        # 账号列表批量下载会先统一列一次列表；这里重复列会导致选中多账号时浏览器长时间等待下载确认。
        meta = {"name": name}
    else:
        meta = find_cpa_codex_auth_file(email=email, local_filename=local_filename)
        name = str((meta or {}).get("name") or "").strip()
    if not name:
        target = email or local_filename or cpa_name or "未知"
        raise RuntimeError(f"[Codex][CPA] 未在 CPA auth-files 中找到匹配的 Codex 凭证: {target}")
    text = _cpa_request_raw("GET", f"/v0/management/auth-files/download?name={quote(name, safe='')}", response_type="text")
    # 下载接口正常应返回 JSON 文本，这里做一次轻校验，避免把 HTML/错误文本当凭证导出。
    try:
        parsed = json.loads(text)
    except Exception as exc:
        raise RuntimeError(f"[Codex][CPA] CPA 下载内容不是有效 JSON: {name}") from exc
    if not isinstance(parsed, dict):
        raise RuntimeError(f"[Codex][CPA] CPA 下载内容不是 JSON 对象: {name}")
    return json.dumps(parsed, ensure_ascii=False, indent=2) + "\n", name, (meta or {"name": name})

def _first_non_empty(*values) -> str:
    for value in values:
        text = str(value or "").strip()
        if text:
            return text
    return ""


def _extract_state_from_auth_url(auth_url: str) -> str:
    try:
        return parse_qs(urlparse(auth_url).query).get("state", [""])[0]
    except Exception:
        return ""


def _request_cpa_authorize_url() -> dict:
    """从 CPA 生成 Codex OAuth 授权地址；本地不生成 PKCE。"""
    logger.info("[Codex][CPA] 正在通过 CPA 管理接口生成授权地址...")
    payload = _cpa_request_json("GET", "/v0/management/codex-auth-url")
    data = payload.get("data") if isinstance(payload.get("data"), dict) else {}
    auth_url = _first_non_empty(
        payload.get("url"),
        payload.get("auth_url"),
        payload.get("authUrl"),
        data.get("url"),
        data.get("auth_url"),
        data.get("authUrl"),
    )
    state = _first_non_empty(
        payload.get("state"),
        payload.get("auth_state"),
        payload.get("authState"),
        data.get("state"),
        data.get("auth_state"),
        data.get("authState"),
        _extract_state_from_auth_url(auth_url),
    )
    if not auth_url.startswith("http"):
        raise RuntimeError(f"[Codex][CPA] CPA 未返回有效 auth_url: {payload}")
    if not state:
        raise RuntimeError("[Codex][CPA] CPA 授权地址缺少 state")
    logger.info("[Codex][CPA] 已获取授权地址（state 与完整 URL 不写日志）")
    return {
        "auth_url": auth_url,
        "state": state,
        "origin": _cpa_management_origin(),
        "raw": payload,
    }


def _is_cpa_callback_retryable(exc: Exception) -> bool:
    text = str(exc or "").lower()
    return (
        "status=409" in text
        or "timeout waiting for oauth callback" in text
        or "timeout" in text
        or "timed out" in text
        or "connection" in text
        or "status=429" in text
        or "status=500" in text
        or "status=502" in text
        or "status=503" in text
        or "status=504" in text
    )


def _is_cpa_callback_reauth_error(exc_or_text) -> bool:
    """CPA 收到 callback 后仍 409 timeout，通常需要重新生成授权地址重新跑一轮 OAuth。"""
    text = str(exc_or_text or "").lower()
    return (
        "oauth-callback" in text
        and "status=409" in text
        and "timeout waiting for oauth callback" in text
    ) or (
        "timeout waiting for oauth callback" in text
    )


def _submit_cpa_callback(callback_url: str) -> dict:
    """提交 OAuth callback 给 CPA。

    CPA 偶发会在浏览器已拿到 localhost callback 后仍返回
    “409 Timeout waiting for OAuth callback”，通常是管理端等待/入库的竞态；
    这里按同一个 callback URL 做多次重试，不重新生成授权地址。
    """
    body = {
        "provider": "codex",
        "redirect_url": str(callback_url or "").strip(),
    }
    max_attempts = max(1, int(getattr(_cfg, "CPA_CALLBACK_SUBMIT_RETRIES", 5) or 5))
    base_delay = max(1.0, float(getattr(_cfg, "CPA_CALLBACK_SUBMIT_RETRY_DELAY", 6) or 6))
    last_exc = None
    for attempt in range(1, max_attempts + 1):
        try:
            logger.info(
                "[Codex][CPA] 正在提交 OAuth callback 给 CPA（第 %s/%s 次；回调值不写日志）",
                attempt, max_attempts,
            )
            payload = _cpa_request_json("POST", "/v0/management/oauth-callback", body)
            logger.info("[Codex][CPA] callback 已提交（第 %s 次成功）", attempt)
            return payload
        except Exception as exc:
            last_exc = exc
            retryable = _is_cpa_callback_retryable(exc)
            if attempt >= max_attempts or not retryable:
                logger.warning(
                    "[Codex][CPA] callback 提交失败且不再重试：attempt=%s/%s retryable=%s error=%s",
                    attempt, max_attempts, retryable, exc
                )
                raise
            delay = base_delay * attempt
            logger.warning(
                "[Codex][CPA] callback 提交失败，将在 %.1fs 后重试：attempt=%s/%s error=%s",
                delay, attempt, max_attempts, exc
            )
            time.sleep(delay)
    raise RuntimeError(f"[Codex][CPA] callback 提交失败：{last_exc}")


# ============================================================
# 小工具：判定/解析
# ============================================================

def _is_redirect_uri(location: str) -> bool:
    """判断 Location 是否指向注册的 redirect_uri（localhost:1455/auth/callback）。"""
    try:
        parsed = urlparse(location)
    except Exception:
        return False
    return parsed.scheme in ("http", "https") and \
        parsed.hostname in ("localhost", "127.0.0.1") and \
        parsed.port == 1455 and \
        parsed.path == "/auth/callback"


def _extract_code(location: str, state: str) -> str:
    """从 redirect_uri 的 Location 里提取并校验 code。"""
    parsed = urlparse(location)
    qs = parse_qs(parsed.query)
    err = (qs.get("error") or [""])[0]
    if err:
        err_desc = (qs.get("error_description") or [""])[0]
        raise RuntimeError(f"[Codex] 授权服务器返回错误: error={err}, desc={err_desc}")
    code = (qs.get("code") or [""])[0]
    if not code:
        raise RuntimeError(f"[Codex] redirect_uri 缺少 code 参数: {location}")
    returned_state = (qs.get("state") or [""])[0]
    if returned_state and returned_state != state:
        raise RuntimeError(
            f"[Codex] state 不匹配（疑似 CSRF）: expected={state[:8]}..., got={returned_state[:8]}..."
        )
    return code


def _decode_jwt_segment(seg: str) -> dict:
    """base64url 解码一个 JWT/cookie 段为 JSON dict（失败返回 {}）。"""
    try:
        padding = "=" * (-len(seg) % 4)
        return json.loads(base64.urlsafe_b64decode(seg + padding))
    except Exception:
        return {}


def _post_json(session: BrowserSession, url: str, payload: dict, referer: str,
               sentinel_header: str | None = None, so_header: str | None = None):
    """统一发 /api/accounts/* 的 JSON POST。"""
    headers = session.get_auth_headers(referer=referer)
    if sentinel_header:
        headers["openai-sentinel-token"] = sentinel_header
    if so_header:
        headers["openai-sentinel-so-token"] = so_header
    resp = session.post(url, headers=headers, data=json.dumps(payload), allow_redirects=False)
    _cache_auth_session_metadata(session, resp)
    return resp


def _resp_json(resp) -> dict:
    try:
        return resp.json()
    except Exception:
        return {}


def _response_text(resp) -> str:
    try:
        data = resp.json()
        if isinstance(data, dict):
            parts = []
            def walk(x):
                if isinstance(x, dict):
                    for v in x.values(): walk(v)
                elif isinstance(x, list):
                    for v in x: walk(v)
                elif x is not None:
                    parts.append(str(x))
            walk(data)
            return " ".join(parts)
    except Exception:
        pass
    return str(getattr(resp, 'text', '') or '')


def _decode_auth_session_metadata(value) -> dict:
    """把响应中的 oai-client-auth-session 转成 workspace payload。"""
    if isinstance(value, dict):
        return value
    if not isinstance(value, str) or not value.strip():
        return {}
    return _decode_jwt_segment(value.split(".", 1)[0])


def _cache_auth_session_metadata(session: BrowserSession, resp) -> None:
    """缓存 Auth 响应携带的 session 元数据，供 cookie 缺失时恢复 workspace。"""
    try:
        payload = _resp_json(resp)
        if not isinstance(payload, dict):
            return
        value = payload.get("oai-client-auth-session")
        if value is None:
            value = payload.get("auth_session") or payload.get("authSession")
        cached = _decode_auth_session_metadata(value)
        if cached:
            session._codex_auth_session_payload = cached
    except Exception:
        logger.debug("[Codex] 缓存 Auth session 元数据失败", exc_info=True)


def _phone_failure_reason(text: str, status_code: int | None = None) -> str:
    low = str(text or '').lower()
    if 'whatsapp' in low or 'whats app' in low:
        return 'whatsapp_channel'
    if any(k in low for k in (
        'phone number is not valid', 'invalid phone number', 'invalid phone', 'not a valid phone',
        '号码无效', '手机号无效', '电话号码无效', 'invalid_number', 'invalid_phone',
    )):
        return 'invalid_phone'
    if any(k in low for k in (
        'cannot send', "can't send", 'could not send', "couldn't send", 'unable to send',
        'cannot deliver', 'unable to deliver', 'failed to send', 'send failed',
        '无法发送', '不能发送', '无法向', '发送验证码', '发送短信',
    )):
        return 'delivery_refused'
    if any(k in low for k in ('too many', 'rate limit', 'throttle', 'limited', '频繁', '限流')):
        return 'send_limited'
    if any(k in low for k in ('already used', 'used too many', 'maximum', '上限', '已被使用')):
        return 'phone_used_or_max'
    if status_code and status_code >= 500:
        return 'server_error'
    if status_code and status_code >= 400:
        return 'send_rejected'
    return ''


# ============================================================
# 步骤 0：用全新 session 跟随 Codex authorize URL，建立 auth.openai.com 会话
# ============================================================

def _bootstrap_authorize(
    session: BrowserSession,
    state: str,
    code_challenge: str | None = None,
    auth_url: str | None = None,
) -> None:
    """
    GET Codex authorize URL 并跟随重定向，落到登录页，建立 auth.openai.com cookies
    （含 oai-client-auth-session：内含 Codex 目标 + 后续要用的 workspace 列表）。
    """
    # 默认使用调用方传入的 CPA 授权地址；未传时才走保留的本地 PKCE 生成逻辑。
    if not auth_url:
        if not code_challenge:
            raise RuntimeError("[Codex] 本地生成授权地址需要 code_challenge")
        auth_url = _build_authorize_url(state, code_challenge, prompt="login")
    auth_url = _ensure_oai_context_url(auth_url, session)
    # Codex CLI/CPA 授权地址是用户从外部客户端直接打开的顶层导航，不是从
    # chatgpt.com 页面点击而来。使用 sec-fetch-site:none 且不伪造 Referer。
    headers = session.get_auth_navigate_headers(referer="", user_initiated=True)
    logger.info("[Codex] 跟随 Codex authorize URL 建立会话（查询参数不写日志）...")
    resp = _with_auth_navigation_retry(
        session,
        "bootstrap authorize",
        lambda: session.get(auth_url, headers=headers, allow_redirects=True),
    )
    logger.debug(
        "[Codex] authorize 落点: %s, status=%s",
        _safe_url_for_log(getattr(resp, "url", "")),
        getattr(resp, "status_code", ""),
    )


# ============================================================
# 步骤 1：提交邮箱（触发邮箱 OTP 发送）
# ============================================================

def _submit_email(session: BrowserSession, email: str) -> dict:
    """POST authorize/continue 提交邮箱，让 Auth 服务返回下一步（密码页/OTP 页等）。带 sentinel。"""
    sentinel_resp = request_sentinel_token(session, "authorize_continue")
    sentinel_header, so_header = build_sentinel_header(session, sentinel_resp, "authorize_continue")
    payload = {"username": {"kind": "email", "value": email}}
    resp = _post_json(
        session,
        "https://auth.openai.com/api/accounts/authorize/continue",
        payload,
        referer="https://auth.openai.com/log-in",
        sentinel_header=sentinel_header,
        so_header=so_header,
    )
    if resp.status_code not in (200, 204):
        raise RuntimeError(
            f"[Codex] 提交邮箱失败 status={resp.status_code}: {(resp.text or '')[:300]}"
        )
    result = _resp_json(resp)
    logger.info(
        "[Codex] 已提交邮箱 %s，Auth 下一步：page=%s continue=%s",
        email,
        _page_type(result) or "-",
        _extract_continue_url(result) or "-",
    )
    return result


def _extract_continue_url(result: dict | None) -> str:
    """从 Auth JSON 响应中提取 continue/redirect URL。"""
    if not isinstance(result, dict):
        return ""
    page = result.get("page") or {}
    page = page if isinstance(page, dict) else {}
    return str(
        result.get("continue_url")
        or result.get("external_url")
        or result.get("redirect_url")
        or result.get("url")
        or page.get("continue_url")
        or page.get("external_url")
        or page.get("redirect_url")
        or page.get("url")
        or ""
    ).strip()


def _extract_factor_id(result: dict | None, continue_url: str = "") -> str:
    """从 MFA 响应或 /mfa-challenge/<factor_id> URL 中提取 factor_id。"""
    if isinstance(result, dict):
        factor_id = str(result.get("factor_id") or result.get("id") or "").strip()
        if factor_id:
            return factor_id
        page = result.get("page") or {}
        page = page if isinstance(page, dict) else {}
        payload = page.get("payload") or {}
        if isinstance(payload, dict):
            factor_id = str(payload.get("factor_id") or payload.get("id") or "").strip()
            if factor_id:
                return factor_id
    if "/mfa-challenge/" in continue_url:
        return continue_url.rstrip("/").rsplit("/", 1)[-1]
    return ""


def _page_type(result: dict | None) -> str:
    if not isinstance(result, dict):
        return ""
    page = result.get("page") or {}
    return str((page if isinstance(page, dict) else {}).get("type") or "").strip()


def _result_text(result: dict | None) -> str:
    """把 Auth 返回的嵌套结果压平成可匹配文本，不依赖单一字段名。"""
    try:
        return json.dumps(result or {}, ensure_ascii=False, separators=(",", ":")).lower()
    except Exception:
        return str(result or "").lower()


def _result_has_any(result: dict | None, *terms: str) -> bool:
    text = _result_text(result)
    return any(str(term).lower() in text for term in terms)


def _is_password_step(result: dict | None) -> bool:
    return _result_has_any(
        result,
        "log-in/password",
        "login/password",
        "password_verify",
        '"page":"password"',
        '"type":"password"',
        '"type":"login_password"',
    )


def _is_email_otp_step(result: dict | None) -> bool:
    return _result_has_any(
        result,
        "email-verification",
        "email_otp",
        "email-otp",
        "email_otp_send",
    )


def _is_mfa_step(result: dict | None, continue_url: str = "") -> bool:
    return "/mfa-challenge/" in str(continue_url or "").lower() or _result_has_any(
        result,
        "mfa-challenge",
        "mfa_challenge",
        "totp",
        '"type":"mfa"',
    )


def _is_phone_step(result: dict | None) -> bool:
    return _result_has_any(
        result,
        "add-phone",
        "add_phone",
        "phone-verification",
        "phone_verification",
        "phone_otp",
    )


def _password_verify(session: BrowserSession, password: str) -> dict:
    """提交登录密码。"""
    sentinel_resp = request_sentinel_token(session, "password_verify")
    sentinel_header, so_header = build_sentinel_header(session, sentinel_resp, "password_verify")
    resp = _post_json(
        session,
        "https://auth.openai.com/api/accounts/password/verify",
        {"password": password},
        referer="https://auth.openai.com/log-in/password",
        sentinel_header=sentinel_header,
        so_header=so_header,
    )
    if resp.status_code != 200:
        raise RuntimeError(
            f"[Codex] 密码验证失败 status={resp.status_code}: {(resp.text or '')[:300]}"
        )
    logger.info("[Codex] 密码验证通过")
    return _resp_json(resp)


def _mfa_issue_challenge(session: BrowserSession, factor_id: str) -> dict:
    """发起 TOTP MFA challenge。"""
    resp = _post_json(
        session,
        "https://auth.openai.com/api/accounts/mfa/issue_challenge",
        {"id": factor_id, "type": "totp", "force_fresh_challenge": False},
        referer="https://auth.openai.com/mfa-challenge",
    )
    if resp.status_code != 200:
        raise RuntimeError(
            f"[Codex] MFA challenge 发起失败 status={resp.status_code}: {(resp.text or '')[:300]}"
        )
    return _resp_json(resp)


def _mfa_verify(session: BrowserSession, factor_id: str, code: str) -> dict:
    """提交 TOTP MFA 验证码。"""
    resp = _post_json(
        session,
        "https://auth.openai.com/api/accounts/mfa/verify",
        {"id": factor_id, "type": "totp", "code": code},
        referer=f"https://auth.openai.com/mfa-challenge/{factor_id}",
    )
    if resp.status_code != 200:
        raise RuntimeError(
            f"[Codex] MFA 验证失败 status={resp.status_code}: {(resp.text or '')[:300]}"
        )
    logger.info("[Codex] MFA/TOTP 验证通过")
    return _resp_json(resp)


def _complete_mfa_if_required(session: BrowserSession, email: str, result: dict | None) -> dict:
    """仅当 Auth 当前结果明确要求 MFA 时，提交账号 TOTP 并返回下一状态。"""
    continue_url = _extract_continue_url(result)
    if not _is_mfa_step(result, continue_url):
        return result or {}

    factor_id = _extract_factor_id(result, continue_url)
    if not factor_id:
        raise RuntimeError(f"[Codex] Auth 要求 MFA，但未拿到 factor_id：{result}")
    code = _account_totp_code(email)
    if not code:
        raise RuntimeError(f"[Codex] Auth 要求 MFA，但账号没有可用 totp_secret：{email}")

    logger.info("[Codex] Auth 要求 MFA，开始提交账号 TOTP：%s factor_id=%s", email, factor_id)
    _mfa_issue_challenge(session, factor_id)
    return _mfa_verify(session, factor_id, code)


def _follow_login_continue(
    session: BrowserSession,
    continue_url: str,
    state: str,
    callback_matcher=None,
) -> str | None:
    """
    密码/MFA 成功后的 continue URL 可能直接跳 callback，也可能只把会话推进到
    consent 页面。``callback_matcher`` 让标准 Web OAuth 使用 platform callback，
    同时保持旧 Codex localhost callback 行为不变。
    """
    if not continue_url:
        return None
    url = continue_url if continue_url.startswith("http") else ("https://auth.openai.com" + continue_url)
    for hop in range(_MAX_REDIRECTS):
        if _is_redirect_uri(url) or (callback_matcher and callback_matcher(url)):
            return url
        headers = session.get_auth_navigate_headers(referer="https://auth.openai.com/", user_initiated=True)
        resp = session.get(url, headers=headers, allow_redirects=False)
        loc = resp.headers.get("location") or resp.headers.get("Location")
        logger.debug(
            "[Codex] 登录 continue 跟随 hop %s: status=%s, location=%s",
            hop, getattr(resp, "status_code", ""), loc,
        )
        if not loc:
            return None
        url = loc if loc.startswith("http") else ("https://auth.openai.com" + loc)
    raise RuntimeError(f"[Codex] 登录 continue 跟随超过 {_MAX_REDIRECTS} 跳")


def _try_password_mfa_login(
    session: BrowserSession,
    email: str,
    state: str,
    initial_result: dict | None,
    callback_matcher=None,
) -> tuple[str, str | None, dict]:
    """
    有注册密码时优先走密码登录；如进入 MFA challenge，则使用账号 totp_secret 生成 TOTP。

    返回:
      ("logged_in", callback_url_or_None, result)  已完成密码/MFA 登录
      ("email_otp", None, result)                  服务端要求邮箱 OTP
      ("not_applicable", None, result)            当前实际页面不是密码页
    """
    password = _account_registration_password(email)
    if not password or not _is_password_step(initial_result):
        logger.info(
            "[Codex] 当前 Auth 未要求密码，按服务端返回继续：email=%s page=%s continue=%s",
            email,
            _page_type(initial_result) or "-",
            _extract_continue_url(initial_result) or "-",
        )
        return "not_applicable", None, initial_result or {}

    logger.info("[Codex] 账号存在注册密码，优先走密码登录：%s", email)
    result = _password_verify(session, password)
    continue_url = _extract_continue_url(result)
    page_type = _page_type(result)

    if _is_mfa_step(result, continue_url) or page_type == "mfa_challenge":
        result = _complete_mfa_if_required(session, email, result)
        continue_url = _extract_continue_url(result) or continue_url
        page_type = _page_type(result)

    if _is_email_otp_step(result) or page_type in {"email_verification", "email_otp_send"}:
        logger.info("[Codex] 密码登录后服务端仍要求邮箱 OTP，切换到邮箱 OTP：%s", email)
        return "email_otp", None, result

    callback_url = _follow_login_continue(
        session,
        continue_url,
        state,
        callback_matcher=callback_matcher,
    ) if continue_url else None
    logger.info("[Codex] 密码/MFA 登录链已完成，继续 Codex workspace/callback：%s", email)
    return "logged_in", callback_url, result


# ============================================================
# 步骤 2：提交邮箱 OTP
# ============================================================

def _submit_email_otp(session: BrowserSession, code: str) -> dict:
    """POST email-otp/validate 提交邮箱验证码。带 sentinel(authorize_continue)。"""
    sentinel_resp = request_sentinel_token(session, "authorize_continue")
    sentinel_header, so_header = build_sentinel_header(session, sentinel_resp, "authorize_continue")
    resp = _post_json(
        session,
        "https://auth.openai.com/api/accounts/email-otp/validate",
        {"code": code},
        referer="https://auth.openai.com/email-verification",
        sentinel_header=sentinel_header,
        so_header=so_header,
    )
    if resp.status_code != 200:
        error_code = _extract_error_code(resp)
        if error_code in ("account_deactivated", "account_deleted", "account_banned"):
            raise AccountUnusableError(
                f"[Codex] 账号已废（{error_code}）status={resp.status_code}: {(resp.text or '')[:200]}",
                error_code=error_code,
            )
        body_error_code = detect_account_unusable_response_body(resp.text or "")
        if body_error_code:
            raise AccountUnusableError(
                f"[Codex] 账号已废（{body_error_code}）status={resp.status_code}: {(resp.text or '')[:200]}",
                error_code=body_error_code,
            )
        raise RuntimeError(
            f"[Codex] 邮箱 OTP 验证失败 status={resp.status_code}: {(resp.text or '')[:300]}"
        )
    logger.info("[Codex] 邮箱 OTP 验证通过")
    result = _resp_json(resp)
    logger.info(
        "[Codex] 邮箱 OTP 后 Auth 下一步：page=%s continue=%s phone=%s mfa=%s",
        _page_type(result) or "-",
        _extract_continue_url(result) or "-",
        _is_phone_step(result),
        _is_mfa_step(result, _extract_continue_url(result)),
    )
    return result


# ============================================================
# 步骤 3-4：手机号验证（接码，失败换号重试）
# ============================================================

def _sms_provider_name() -> str:
    """当前接码通道名，仅用于 Codex 流程日志。"""
    return str(getattr(_cfg, "SMS_PROVIDER", "grizzly") or "grizzly").strip().lower()


def _sleep_before_phone_retry(attempt: int, max_retries: int, *, prefix: str = "[Codex]") -> None:
    """换号前随机等待，至少 3 秒，避免连续提交号码过快。"""
    if attempt >= max_retries:
        return
    seconds = random.uniform(3.0, 8.0)
    logger.info(f"{prefix} 换号前随机等待 {seconds:.1f} 秒")
    time.sleep(seconds)


def _do_phone_verification(session: BrowserSession) -> dict:
    """
    用接码平台拿号 → add-phone/send 发短信 → 收码 → phone-otp/validate。
    一个号收不到码或被 OpenAI 拒就取消换号，最多 SMS_MAX_RETRIES 次（热加载）。

    实际平台适配在 core.sms_provider：
        - SMS_PROVIDER="grizzly"：GrizzlySMS handler_api.php
        - SMS_PROVIDER="l"：L_API.md 的 /take-phone 和 /fetch-code JSON 接口
    """
    http = sms_provider._http()
    max_retries = _cfg.SMS_MAX_RETRIES
    provider = _sms_provider_name()
    try:
        last_err = None
        for attempt in range(1, max_retries + 1):
            activation_id = None
            try:
                activation_id, phone = sms_provider.acquire_number(http)
                logger.info(
                    f"[Codex] 手机验证尝试 {attempt}/{max_retries}，"
                    f"provider={provider}, activation_id={activation_id}, 号码=+{phone}"
                )

                # 发短信
                send_resp = _post_json(
                    session,
                    "https://auth.openai.com/api/accounts/add-phone/send",
                    {"phone_number": f"+{phone}", "channel": "sms"},
                    referer="https://auth.openai.com/add-phone",
                )
                send_text = _response_text(send_resp)
                send_reason = _phone_failure_reason(send_text, send_resp.status_code)
                if send_resp.status_code not in (200, 204) or send_reason:
                    # 号码无效 / 无法发送 / WhatsApp 通道 / 限流等 → 释放当前号并换号。
                    logger.warning(
                        f"[Codex] add-phone/send 未成功 reason={send_reason or 'unknown'}, "
                        f"status={send_resp.status_code}: {send_text[:240]}，换号重试"
                    )
                    sms_provider.cancel(activation_id, http)
                    _sleep_before_phone_retry(attempt, max_retries)
                    continue

                # 通知平台短信已发出（status=1）
                sms_provider.set_status(activation_id, 1, http=http)

                # 定时轮询接码平台获取短信。wait_for_sms_code 内部按 SMS_POLL_INTERVAL 轮询，
                # 最长等待 SMS_CODE_WAIT；超时立即取消当前号并换号。
                try:
                    logger.info(
                        f"[Codex] 短信已发送，开始轮询验证码 activation_id={activation_id}, "
                        f"wait={_cfg.SMS_CODE_WAIT}s, interval={_cfg.SMS_POLL_INTERVAL}s"
                    )
                    sms_code = sms_provider.wait_for_sms_code(activation_id, http)
                except sms_provider.SmsCodeTimeout:
                    logger.warning(f"[Codex] 号码 +{phone} 在 {_cfg.SMS_CODE_WAIT}s 内未收到短信，取消换号")
                    sms_provider.cancel(activation_id, http)
                    _sleep_before_phone_retry(attempt, max_retries)
                    continue

                # 验手机码
                val_resp = _post_json(
                    session,
                    "https://auth.openai.com/api/accounts/phone-otp/validate",
                    {"code": sms_code},
                    referer="https://auth.openai.com/phone-verification",
                )
                if val_resp.status_code != 200:
                    val_text = _response_text(val_resp)
                    val_reason = _phone_failure_reason(val_text, val_resp.status_code) or 'code_rejected'
                    logger.warning(
                        f"[Codex] phone-otp/validate 失败 reason={val_reason}, status={val_resp.status_code}: "
                        f"{val_text[:240]}，换号重试"
                    )
                    sms_provider.cancel(activation_id, http)
                    _sleep_before_phone_retry(attempt, max_retries)
                    continue

                # 成功
                sms_provider.complete(activation_id, http)
                logger.info("[Codex] 手机号验证通过")
                return _resp_json(val_resp)

            except sms_provider.SmsNoBalanceError:
                # 余额不足，重试无意义，直接抛
                raise
            except sms_provider.SmsProviderError as exc:
                last_err = exc
                logger.warning(f"[Codex] 接码尝试 {attempt} 失败：{exc}")
                if activation_id:
                    sms_provider.cancel(activation_id, http)
                _sleep_before_phone_retry(attempt, max_retries)
                continue

        raise RuntimeError(
            f"[Codex] 手机号验证重试 {max_retries} 次仍失败（provider={provider}）"
            + (f"，最后错误：{last_err}" if last_err else "")
        )
    finally:
        http.close()


# ============================================================
# 步骤 5：选 workspace → 拿 callback code
# ============================================================

def _get_workspace_id(session: BrowserSession) -> str:
    """
    优先从 oai-client-auth-session cookie 解出 workspace；cookie 尚未落地时，
    退回 Auth 响应元数据，并在有界时间内等待 cookie/响应状态完成。
    """
    def find_workspace_id(payload: dict) -> str:
        for workspace in payload.get("workspaces") or []:
            if isinstance(workspace, dict) and workspace.get("id"):
                return str(workspace["id"])
        return ""

    deadline = time.monotonic() + max(0.0, float(_WORKSPACE_COOKIE_WAIT_SECONDS))
    while True:
        raw = None
        try:
            for c in session.session.cookies.jar:
                if c.name == "oai-client-auth-session":
                    raw = c.value
                    break
        except Exception:
            pass
        if not raw:
            try:
                raw = session.session.cookies.get("oai-client-auth-session")
            except Exception:
                raw = None

        if raw:
            wid = find_workspace_id(_decode_auth_session_metadata(raw))
            if wid:
                logger.info(f"[Codex] workspace_id={wid}")
                return wid

        wid = find_workspace_id(getattr(session, "_codex_auth_session_payload", {}) or {})
        if wid:
            logger.info(f"[Codex] workspace_id={wid}（来自 Auth 响应元数据）")
            return wid

        remaining = deadline - time.monotonic()
        if remaining <= 0:
            if not raw:
                raise RuntimeError("[Codex] 找不到 oai-client-auth-session cookie，无法取 workspace_id")
            raise RuntimeError("[Codex] oai-client-auth-session 中无可用 workspace_id")
        time.sleep(min(_WORKSPACE_POLL_INTERVAL_SECONDS, remaining))


def _select_workspace_and_get_callback(session: BrowserSession, state: str) -> str:
    """
    POST workspace/select，然后跟随后续重定向/响应里的 URL 直到命中 localhost:1455 callback。
    返回完整 callback URL（含 code）。
    """
    wid = _get_workspace_id(session)
    resp = _post_json(
        session,
        "https://auth.openai.com/api/accounts/workspace/select",
        {"workspace_id": wid},
        referer="https://auth.openai.com/sign-in-with-chatgpt/codex/consent",
    )

    # 1) 直接带 Location 头命中 callback
    loc = resp.headers.get("location") or resp.headers.get("Location")
    if loc and _is_redirect_uri(loc):
        return loc

    # 2) 响应 JSON 里给了下一步 URL（continue_url / redirect_url / url / next）
    data = _resp_json(resp)
    next_url = None
    for key in ("redirect_url", "continue_url", "url", "next", "location"):
        v = data.get(key)
        if isinstance(v, str) and v:
            next_url = v
            break

    # 3) 没给 URL 但有 Location（非 callback）→ 从 Location 起跟
    if not next_url and loc:
        next_url = loc

    if not next_url:
        raise RuntimeError(
            f"[Codex] workspace/select 后找不到下一跳 URL: status={resp.status_code}, "
            f"body={(resp.text or '')[:300]}"
        )

    # 跟随重定向链直到命中 callback
    return _follow_until_callback(session, next_url, state)


def _follow_until_callback(session: BrowserSession, url: str, state: str) -> str:
    """从给定 URL 起逐跳跟随，命中 localhost:1455 callback 时返回其 Location。"""
    if url.startswith("/"):
        url = "https://auth.openai.com" + url
    for hop in range(_MAX_REDIRECTS):
        if _is_redirect_uri(url):
            return url
        headers = session.get_auth_navigate_headers(referer="https://auth.openai.com/")
        resp = session.get(url, headers=headers, allow_redirects=False)
        loc = resp.headers.get("location") or resp.headers.get("Location")
        logger.debug(
            "[Codex] callback 跟随 hop %s: status=%s, location=%s",
            hop,
            getattr(resp, "status_code", ""),
            _safe_url_for_log(loc),
        )
        if loc is None:
            raise RuntimeError(
                f"[Codex] 跟随中断，未命中 callback: url={_safe_url_for_log(url)}, "
                f"status={getattr(resp,'status_code','')}"
            )
        if _is_redirect_uri(loc):
            return loc
        url = loc if loc.startswith("http") else ("https://auth.openai.com" + loc)
    raise RuntimeError(f"[Codex] 跟随 callback 超过 {_MAX_REDIRECTS} 跳")


# ============================================================
# 换 token（对照 CLIProxyAPI ExchangeCodeForTokensWithRedirect）—— 未改动
# ============================================================

def exchange_codex_token(session: BrowserSession, code: str, code_verifier: str) -> dict:
    """用 authorization code 换 token。"""
    data = {
        "grant_type": "authorization_code",
        "client_id": _cfg.CODEX_CLIENT_ID,
        "code": code,
        "redirect_uri": _cfg.CODEX_REDIRECT_URI,
        "code_verifier": code_verifier,
    }
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "application/json",
    }
    base = session._get_common_headers()
    base.update(headers)
    headers = base

    logger.info("[Codex] 用 authorization code 换 token...")
    resp = session.post(_cfg.CODEX_TOKEN_URL, headers=headers, data=urlencode(data))
    http_status = resp.status_code
    if http_status != 200:
        raise RuntimeError(
            f"[Codex] 换 token 失败 status={http_status}: {(resp.text or '')[:300]}"
        )
    token_resp = resp.json()
    if not token_resp.get("access_token"):
        raise RuntimeError(f"[Codex] token 响应缺少 access_token: {token_resp}")
    logger.info(
        f"[Codex] 换 token 成功，expires_in={token_resp.get('expires_in')}, "
        f"access_token={token_resp['access_token'][:16]}..."
    )
    return token_resp


# ============================================================
# 解析 id_token / 落盘 —— 未改动
# ============================================================

def _parse_id_token(id_token: str) -> dict:
    """base64 解码 JWT payload（不验签），抽 email / account_id / plan_type。"""
    if not id_token:
        return {}
    try:
        parts = id_token.split(".")
        if len(parts) < 2:
            return {}
        claims = _decode_jwt_segment(parts[1])
    except Exception as exc:
        logger.warning("[Codex] id_token 解析失败: %s", _safe_sensitive_text(exc))
        return {}

    auth_claim = claims.get("https://api.openai.com/auth", {}) or {}
    profile_claim = claims.get("https://api.openai.com/profile", {}) or {}
    # OpenAI 新版 id_token 的 email 在顶层 claim；旧版/CLIProxyAPI 实现里在 profile_claim。
    # 顶层优先，否则回退 profile_claim，避免落盘的 codex-邮箱.json 里 email 字段为空。
    email_value = claims.get("email") or profile_claim.get("email", "")
    return {
        "email": email_value,
        "account_id": auth_claim.get("chatgpt_account_id", ""),
        "plan_type": auth_claim.get("chatgpt_plan_type", ""),
    }


def build_codex_storage(token_resp: dict, id_claims: dict) -> dict:
    """组装 CLIProxyAPI CodexTokenStorage JSON 结构。"""
    expires_in = token_resp.get("expires_in", 0) or 0
    expired_dt = datetime.now(timezone.utc) + _timedelta_seconds(expires_in)
    last_refresh_dt = datetime.now(timezone.utc)
    return {
        "id_token": token_resp.get("id_token", ""),
        "access_token": token_resp.get("access_token", ""),
        "refresh_token": token_resp.get("refresh_token", ""),
        "account_id": id_claims.get("account_id", ""),
        "last_refresh": last_refresh_dt.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "email": id_claims.get("email", ""),
        "type": "codex",
        "expired": expired_dt.strftime("%Y-%m-%dT%H:%M:%SZ"),
    }


def _timedelta_seconds(seconds: int):
    from datetime import timedelta
    return timedelta(seconds=int(seconds))


def _credential_file_name(email: str, plan_type: str) -> str:
    """对照 CLIProxyAPI filename.go：无 plan→codex-{email}.json，否则带 plan 后缀。"""
    email = (email or "").strip()
    plan = (plan_type or "").strip().lower()
    if plan == "":
        return f"codex-{email}.json"
    return f"codex-{email}-{plan}.json"


def save_codex_credential(storage: dict, email: str, plan_type: str) -> str:
    """保存 Codex 凭证到 SQLite，不创建本地文件。"""
    fname = _credential_file_name(email, plan_type)
    db.upsert_codex_credential(storage, fname)
    return f"sqlite://codex_accounts/{fname}"


def _save_codex_credential(email: str, storage: dict) -> str:
    """BrowserUse 兼容入口：同样只保存到 SQLite。"""
    plan = ""
    if isinstance(storage, dict):
        plan = storage.get("plan_type") or storage.get("chatgpt_plan_type") or ""
    return save_codex_credential(storage, email, plan)


def _extract_cpa_auth_json(payload: dict) -> dict | None:
    """
    尝试从 CPA oauth-callback 响应里提取完整授权文件。
    不同 CPA 版本字段名可能不同；只要看起来是 codex auth json 就落本地。
    """
    if not isinstance(payload, dict):
        return None
    candidates = [
        payload.get("auth_json"),
        payload.get("authJson"),
        payload.get("auth"),
        payload.get("auth_file"),
        payload.get("authFile"),
        payload.get("file"),
        payload.get("data"),
    ]
    data = payload.get("data") if isinstance(payload.get("data"), dict) else {}
    candidates.extend([
        data.get("auth_json"),
        data.get("authJson"),
        data.get("auth"),
        data.get("auth_file"),
        data.get("authFile"),
        data.get("file"),
    ])
    for item in candidates:
        if isinstance(item, dict) and (
            item.get("type") == "codex"
            or item.get("access_token")
            or item.get("refresh_token")
            or item.get("id_token")
        ):
            return item
    return None


def _save_cpa_local_record(
    *,
    email: str,
    callback_url: str,
    auth_url: str,
    state: str,
    submit_payload: dict,
) -> str | None:
    """
    在 SQLite 记录 CPA 授权结果：
      1) 如果 CPA 返回完整 auth json，保存为可用 codex-邮箱[-plan].json；
      2) 否则按配置保存 callback 提交回执，便于追踪 CPA 侧授权结果。
    """
    auth_json = _extract_cpa_auth_json(submit_payload)
    if auth_json:
        effective_email = auth_json.get("email") or email
        plan = auth_json.get("plan_type") or auth_json.get("chatgpt_plan_type") or ""
        return save_codex_credential(auth_json, effective_email, plan)

    if not bool(getattr(_cfg, "CPA_SAVE_CALLBACK_RECEIPT", True)):
        return None

    safe_email = (email or "unknown").strip().replace("/", "_").replace("\\", "_")
    fname = f"codex-{safe_email}-cpa-callback.json"
    record = {
        "type": "codex_cpa_callback",
        "email": email,
        "state": state,
        "auth_url": auth_url,
        "callback_url": callback_url,
        "cpa_management_origin": _cpa_management_origin(),
        "cpa_submit_response": submit_payload,
        "submitted_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "note": "授权地址由 CPA 生成；callback 已提交给 CPA。若 CPA 响应未包含 token，本文件为本地回执记录。",
    }
    db.upsert_codex_credential(record, fname)
    return f"sqlite://codex_accounts/{fname}"


def _save_sub2_local_record(
    *,
    email: str,
    callback_url: str,
    auth_url: str,
    state: str,
    submit_payload: dict,
) -> str | None:
    """在 SQLite 记录 sub2 授权结果；若返回完整 auth json，则保存为 Codex 凭证。"""
    auth_json = _extract_cpa_auth_json(submit_payload)
    if auth_json:
        effective_email = auth_json.get("email") or email
        plan = auth_json.get("plan_type") or auth_json.get("chatgpt_plan_type") or ""
        return save_codex_credential(auth_json, effective_email, plan)

    if not bool(getattr(_cfg, "CPA_SAVE_CALLBACK_RECEIPT", True)):
        return None

    safe_email = (email or "unknown").strip().replace("/", "_").replace("\\", "_")
    fname = f"codex-{safe_email}-sub2-callback.json"
    try:
        sub2_origin = _sub2_codex_base()
    except Exception:
        sub2_origin = ""
    record = {
        "type": "codex_sub2_callback",
        "email": email,
        "state": state,
        "auth_url": auth_url,
        "callback_url": callback_url,
        "sub2_origin": sub2_origin,
        "sub2_submit_response": submit_payload,
        "submitted_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "note": "授权地址由 sub2 生成；callback 已上传给 sub2。若 sub2 响应未包含 token，本文件为本地回执记录。",
    }
    db.upsert_codex_credential(record, fname)
    return f"sqlite://codex_accounts/{fname}"


# ============================================================
# 入口
# ============================================================

def _resolve_codex_proxy(proxy: str | None) -> str | None:
    """Resolve Codex proxy mode without changing the global proxy pool."""
    if proxy is not None:
        return proxy
    mode = str(getattr(_cfg, "CODEX_PROXY_MODE", "pool") or "pool").strip().lower()
    if mode in {"direct", "none", "off"}:
        return ""
    return None


def run_codex_oauth(
    email: str,
    otp_provider=None,
    proxy: str | None = None,
    force: bool = False,
    _cpa_reauth_round: int = 1,
) -> dict:
    """
    注册成功后的 Codex OAuth 授权入口（全新 session + 接码方案）。

    不复用注册的 session：内部新建干净 BrowserSession，从头登录该邮箱，
    走 邮箱 OTP → 手机短信验证 → 选 workspace → 拿 code → 换 token → 落盘。

    Args:
        email: 已注册成功的账号邮箱
        otp_provider: 邮箱 OTP 获取回调 fn(email, after_ts)->code，默认用 wait_for_otp
        proxy: 代理（不传从 PROXY_POOL 抽）
        force: True 时跳过 ENABLE_CODEX_AUTO 开关限制，供手动补跑使用

    Returns:
        结构化结果 dict。任何异常都被吞掉转 status=failed，不向上抛，不影响注册主流程。
    """
    if not force and not _cfg.ENABLE_CODEX_AUTO:
        return _codex_result(status="skipped", message="ENABLE_CODEX_AUTO=False")
    if not email:
        return _codex_result(status="skipped", message="email 为空")

    proxy = _resolve_codex_proxy(proxy)

    # Codex OAuth 支持多种驱动：
    # protocol：原纯协议；roxy/cloak/browser_use：用真实浏览器跑页面并捕获 localhost callback。
    try:
        from config import codex as _codex_cfg
        from config import roxybrowser as _roxy_cfg
        oauth_driver = str(getattr(_codex_cfg, "CODEX_OAUTH_DRIVER", "protocol") or "protocol").strip().lower()
        if oauth_driver == "same_as_registration":
            oauth_driver = str(getattr(_roxy_cfg, "REGISTRATION_DRIVER", "protocol") or "protocol").strip().lower()
        if oauth_driver in ("roxy", "roxybrowser", "fingerprint", "browser"):
            # 只读预检放在创建 Roxy Profile 和 OAuth 登录之前，服务不可用时不消耗邮箱/短信资源。
            from core.roxybrowser_client import RoxyBrowserClient
            availability = RoxyBrowserClient().check_availability()
            if not availability.get("ok"):
                message = str(availability.get("message") or "Roxy API 不可用")
                logger.error("[Codex][Roxy] 预检失败：%s", message)
                return _codex_result(status="failed", email=email, message=message)
            logger.info(
                "[Codex][Roxy] 预检通过：reachable=%s status=%s reason=%s elapsed_ms=%s",
                availability.get("reachable"),
                availability.get("status_code"),
                availability.get("reason"),
                availability.get("elapsed_ms"),
            )
            from core.roxy_codex_oauth import run_roxy_codex_oauth
            return run_roxy_codex_oauth(email, otp_provider=otp_provider, proxy=proxy, force=True)
        if oauth_driver in ("browser_use", "browseruse", "browser-use", "bu"):
            from core.browser_use_codex_oauth import run_browser_use_codex_oauth
            return run_browser_use_codex_oauth(email, otp_provider=otp_provider, proxy=proxy, force=True)
        if oauth_driver in ("skyvern", "sv"):
            from core.skyvern_codex_oauth import run_skyvern_codex_oauth
            return run_skyvern_codex_oauth(email, otp_provider=otp_provider, proxy=proxy, force=True)
        if oauth_driver in ("cloak", "cloakbrowser"):
            from config import cloakbrowser as _cloak_cfg
            from core.cloakbrowser_driver import build_cloak_driver
            from core.roxy_codex_oauth import run_roxy_codex_oauth
            driver, opened = build_cloak_driver(proxy=proxy)
            try:
                return run_roxy_codex_oauth(
                    email,
                    otp_provider=otp_provider,
                    proxy=proxy,
                    force=True,
                    existing_driver=driver,
                    existing_opened=opened,
                    reuse_existing_profile=True,
                    clear_existing_state=True,
                )
            finally:
                if not bool(getattr(_cloak_cfg, "CLOAK_KEEP_BROWSER_OPEN", False)):
                    try:
                        driver.quit()
                    except Exception:
                        pass
        if oauth_driver not in ("protocol", "api", "http"):
            raise RuntimeError(f"[Codex] 不支持的 CODEX_OAUTH_DRIVER={oauth_driver!r}，可选 protocol / roxy / cloak / browser_use / skyvern")
    except ImportError:
        # 没装 selenium / 未提供 roxy 配置时继续走协议模式，保持旧行为。
        pass

    if otp_provider is None:
        from core.email_provider import wait_for_otp as otp_provider

    # 单次 Codex 授权全程统一身份；下一任务即使是同一账号也生成全新的隔离身份。
    task_seed = f"codex-oauth:{email.lower()}:{uuid.uuid4()}"
    session = BrowserSession(proxy=proxy, fingerprint_seed=task_seed)
    try:
        logger.info(f"[Codex] 开始授权（全新 session）：{email}")
        logger.info(
            "[Codex] 统一指纹上下文：device_id=%s oai_session_id=%s auth_session_logging_id=%s %s",
            session.device_id,
            session.oai_session_id,
            session.auth_session_logging_id,
            session.fingerprint_summary_text(),
        )

        # 1. 授权地址
        #    默认由 CPA 生成（本地不生成 PKCE/state）；local 模式保留旧代码用于兼容。
        auth_source = _codex_auth_url_source()
        cpa_auth = None
        code_verifier = None
        code_challenge = None
        auth_url = None
        if auth_source == "cpa":
            cpa_auth = _request_cpa_authorize_url()
            state = cpa_auth["state"]
            auth_url = cpa_auth["auth_url"]
            logger.info("[Codex] 当前使用 CPA 授权地址（完整 URL 不写日志）")
        elif auth_source == "sub2":
            sub2_auth = _request_sub2_authorize_url()
            state = sub2_auth["state"]
            auth_url = sub2_auth["auth_url"]
            logger.info("[Codex] 当前使用 sub2 授权地址（完整 URL 不写日志）")
        elif auth_source == "local":
            code_verifier, code_challenge = _generate_pkce()
            state = _generate_state()
            logger.info("[Codex] 当前使用本地 PKCE 生成授权地址，完整 URL 将在 bootstrap 阶段输出")
        else:
            raise RuntimeError(f"[Codex] 不支持的 CODEX_AUTH_URL_SOURCE={auth_source!r}")

        # 2. 网络预检 + 建立会话。预检不携带邮箱，不触发 OTP；
        #    真正烧邮箱的 authorize/continue 只在预检成功后执行。
        _codex_auth_preflight(session)
        human_delay("navigate")

        _bootstrap_authorize(session, state, code_challenge, auth_url=auth_url)
        human_delay("navigate")

        # 3. 提交邮箱。后续不根据“账号有没有密码”猜流程，而是以 Auth 实际返回的
        #    page/type/continue_url 为准；账号密码只是密码页出现时的可用凭证。
        otp_after_ts = time.time()
        auth_result = _submit_email(session, email)
        human_delay("form")
        login_status, early_callback_url, auth_result = _try_password_mfa_login(
            session, email, state, auth_result
        )
        password_login_done = login_status == "logged_in"

        # 4. 只有 Auth 明确把流程推进到邮箱验证页时，才轮询邮箱 OTP。
        if not password_login_done and (
            login_status == "email_otp" or _is_email_otp_step(auth_result)
        ):
            email_otp = None
            max_email_otp_attempts = 3
            for email_otp_attempt in range(1, max_email_otp_attempts + 1):
                logger.info(f"[Codex] 等待邮箱 OTP：{email}（第 {email_otp_attempt}/{max_email_otp_attempts} 次）")
                try:
                    email_otp = otp_provider(email, after_ts=otp_after_ts)
                    break
                except Exception as exc:
                    if email_otp_attempt >= max_email_otp_attempts:
                        raise
                    logger.warning(
                        "[Codex] 一直未收到邮箱 OTP，重新提交邮箱触发重发后继续等待（下一轮 %s/%s）：%s: %s",
                        email_otp_attempt + 1,
                        max_email_otp_attempts,
                        type(exc).__name__,
                        str(exc)[:180],
                    )
                    otp_after_ts = time.time()
                    auth_result = _submit_email(session, email)
                    human_delay("api")
                    retry_status, retry_callback_url, retry_result = _try_password_mfa_login(
                        session, email, state, auth_result
                    )
                    if retry_status == "logged_in":
                        password_login_done = True
                        early_callback_url = retry_callback_url
                        auth_result = retry_result
                        break
            if not password_login_done:
                logger.info("[Codex] 邮箱 OTP 已收到（验证码不写日志）")
                human_delay("otp_input")
                auth_result = _submit_email_otp(session, email_otp)
                human_delay("api")

        # 邮箱验证后仍可能由 Auth 要求 MFA；只有返回 MFA 状态时才提交 TOTP。
        if not password_login_done and _is_mfa_step(
            auth_result, _extract_continue_url(auth_result)
        ):
            auth_result = _complete_mfa_if_required(session, email, auth_result)
            continue_url = _extract_continue_url(auth_result)
            early_callback_url = _follow_login_continue(
                session, continue_url, state
            ) if continue_url else early_callback_url

        # 5. 是否需要手机号也完全由 Auth 返回决定，不再因为走过 OTP/密码而固定执行。
        if _is_phone_step(auth_result):
            logger.info("[Codex] Auth 明确要求手机号验证，开始接码：%s", email)
            phone_result = _do_phone_verification(session)
            phone_continue = _extract_continue_url(phone_result)
            if phone_continue:
                early_callback_url = _follow_login_continue(
                    session, phone_continue, state
                ) or early_callback_url
                auth_result = phone_result
            human_delay("post_auth")
        else:
            logger.info(
                "[Codex] Auth 未要求手机号验证，跳过：email=%s page=%s continue=%s",
                email,
                _page_type(auth_result) or "-",
                _extract_continue_url(auth_result) or "-",
            )

        # 6. 选 workspace → 拿 callback code；若登录 continue 已经直接命中 callback，则复用。
        callback_url = early_callback_url or _select_workspace_and_get_callback(session, state)
        code = _extract_code(callback_url, state)
        logger.info("[Codex] 已拿到 authorization code（内容不写日志）")

        # 7A. CPA 模式：把 callback URL 交给 CPA，由 CPA 持有 verifier 并完成换 token / 写 auth。
        #     本地不再用 code 换 token；仅保存 CPA 返回的授权文件或回调回执。
        if auth_source == "cpa":
            submit_payload = _submit_cpa_callback(callback_url)
            path = _save_cpa_local_record(
                email=email,
                callback_url=callback_url,
                auth_url=auth_url or "",
                state=state,
                submit_payload=submit_payload,
            )
            msg = submit_payload.get("message") or submit_payload.get("status_message") or "CPA callback submitted"
            logger.info(f"[Codex][CPA] 成功：{email}，{msg}，本地记录={path or 'disabled'}")
            return _codex_result(
                status="success",
                ok=True,
                email=email,
                file_path=str(path) if path else None,
                callback_url=callback_url,
                message=str(msg),
            )

        # 7A-sub2. sub2 模式：把 callback URL 上传给 sub2。
        if auth_source == "sub2":
            submit_payload = _submit_sub2_callback(
                callback_url,
                session_id=(sub2_auth or {}).get("session_id", ""),
                redirect_uri=(parse_qs(urlparse(auth_url or "").query).get("redirect_uri") or [""])[0],
            )
            path = _save_sub2_local_record(
                email=email,
                callback_url=callback_url,
                auth_url=auth_url or "",
                state=state,
                submit_payload=submit_payload,
            )
            msg = submit_payload.get("message") or submit_payload.get("status_message") or "sub2 callback uploaded"
            logger.info(f"[Codex][sub2] 成功：{email}，{msg}，本地记录={path or 'disabled'}")
            return _codex_result(
                status="success",
                ok=True,
                email=email,
                file_path=str(path) if path else None,
                callback_url=callback_url,
                message=str(msg),
            )

        # 7B. local 模式：保留旧实现，用本地 verifier 换 token 并保存本地 OAuth 存储记录；
        #      需要目标格式时由 WebUI 的本地导出接口显式转换。
        if not code_verifier:
            raise RuntimeError("[Codex] local 模式缺少 code_verifier")
        token_resp = exchange_codex_token(session, code, code_verifier)

        # 8. 解析 id_token + 落盘
        id_claims = _parse_id_token(token_resp.get("id_token", ""))
        effective_email = id_claims.get("email") or email
        storage = build_codex_storage(token_resp, id_claims)
        path = save_codex_credential(storage, effective_email, id_claims.get("plan_type", ""))

        logger.info(
            f"[Codex] 成功：{effective_email}，plan={id_claims.get('plan_type') or 'unknown'}, "
            f"account_id={id_claims.get('account_id') or 'unknown'}, 已保存到 {path}"
        )
        return _codex_result(
            status="success",
            ok=True,
            email=effective_email,
            file_path=str(path),
            callback_url=callback_url,
            message=f"plan={id_claims.get('plan_type') or 'unknown'}",
        )
    except AccountUnusableError as exc:
        logger.warning(f"[Codex] 账号已废（{exc.error_code}）：{email}")
        return _codex_result(
            status="deactivated",
            email=email,
            message=f"账号已废（{exc.error_code}）",
        )
    except Exception as exc:
        if _is_cpa_callback_reauth_error(exc) and _cpa_reauth_round < 2:
            logger.warning(
                "[Codex][CPA] callback 返回 Timeout waiting for OAuth callback，重新开启第 %s/2 轮 Codex 授权：%s",
                _cpa_reauth_round + 1, email,
            )
            return run_codex_oauth(
                email,
                otp_provider=otp_provider,
                proxy=proxy,
                force=force,
                _cpa_reauth_round=_cpa_reauth_round + 1,
            )
        logger.warning("[Codex] 失败：%s，%s: %s", email, type(exc).__name__, _safe_sensitive_text(exc, limit=200))
        logger.debug("[Codex] 失败详情:", exc_info=True)
        return _codex_result(
            status="failed",
            email=email,
            message=f"{type(exc).__name__}: {str(exc)[:200]}",
        )
